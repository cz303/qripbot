""" Captcha.Visual

This package contains functionality specific to visual CAPTCHA tests.

"""
#
# PyCAPTCHA Package
# Copyright (C) 2004 Micah Dowty <micah@navi.cx>
#

# Convenience imports
from Base import *

### The End ###
